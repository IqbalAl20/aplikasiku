<?php include "header.php";?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Siswa Kita
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <CENTER><h3 class="box-title">DATA SISWA SMK CENDEKIA</h3></CENTER>
            </div>
            <!-- /.box-header -->
            <p><a href="tambah.php"><button class="btn btn-success"><i class="glyphicon glyphicon-plus"></i>Tambah data</button></a></p>
            <div class="box-body">
              <?php
  //proses mengambil data ke database untuk ditampilkan di form edit berdasarkan siswa_id yg didapatkan dari GET id -> edit.php?id=siswa_id
  
  //include atau memasukkan file koneksi ke database
  include('../../../koneksi.php');
  
  //membuat variabel $id yg nilainya adalah dari URL GET id -> edit.php?id=siswa_id
  $id = $_GET['id'];
  
  //melakukan query ke database dg SELECT table siswa dengan kondisi WHERE siswa_id = '$id'
  $show = mysql_query("SELECT * FROM siswa WHERE siswa_id='$id'");
  
  //cek apakah data dari hasil query ada atau tidak
  if(mysql_num_rows($show) == 0){
    
    //jika tidak ada data yg sesuai maka akan langsung di arahkan ke halaman depan atau beranda -> index.php
    echo '<script>window.history.back()</script>';
    
  }else{
  
    //jika data ditemukan, maka membuat variabel $data
    $d = mysql_fetch_assoc($show);  //mengambil data ke database yang nantinya akan ditampilkan di form edit di bawah
  
  }
  ?>
  
  <form action="edit_proses.php" method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?php echo $id; ?>">  <!-- membuat inputan hidden dan nilainya adalah siswa_id -->
    <table cellpadding="7" cellspacing="10">
        <label>NIS</label>
      <div class="form-group">
        <input class="form-control" type="text" name="nis" value="<?php echo $d['siswa_nis']; ?>" required> <!-- value diambil dari hasil query -->
      <tr>
        <label>Nama Lengkap</label>
        <div class="form-group">
        <input class="form-control" type="text" name="namalengkap" size="30" value="<?php echo $d['siswa_nama']; ?>" required> <!-- value diambil dari hasil query -->
      </tr>
      <tr>
        <label>Kelas</label>
        <div class="form-group">
          <select class="form-control" name="kelas" required>
            <option value="">Pilih Kelas</option>
            <option value="X" <?php if($d['siswa_kelas'] == 'X'){ echo 'selected'; } ?>>X</option>  <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="XI" <?php if($d['siswa_kelas'] == 'XI'){ echo 'selected'; } ?>>XI</option> <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="XII" <?php if($d['siswa_kelas'] == 'XII'){ echo 'selected'; } ?>>XII</option>  <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
          </select>
        </td>
      </tr>
      <tr>
        <label>Jurusan</label>
        <div class="form-group">
        
          <select class="form-control" name="jurusan" required>
            <option value="">Pilih Jurusan</option>
            <option value="Teknik Komputer dan Jaringan" <?php if($d['siswa_jurusan'] == 'Teknik Komputer dan Jaringan'){ echo 'selected'; } ?>>Teknik Komputer dan Jaringan</option> <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="Multimedia" <?php if($d['siswa_jurusan'] == 'Multimedia'){ echo 'selected'; } ?>>Multimedia</option> <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="Akuntansi" <?php if($d['siswa_jurusan'] == 'Akuntansi'){ echo 'selected'; } ?>>Akuntansi</option>  <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="Perbankan" <?php if($d['siswa_jurusan'] == 'Perbankan'){ echo 'selected'; } ?>>Perbankan</option>  <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
            <option value="Pemasaran" <?php if($d['siswa_jurusan'] == 'Pemasaran'){ echo 'selected'; } ?>>Pemasaran</option>  <!-- jika data di database sama dengan value maka akan terselect/terpilih -->
          </select>
        </td>
      </tr>
     </tr>
        <input type="submit" name="simpan" value="simpan" class="btn btn-success" >
        </fieldset>
        </form>


              
 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include "footer.php";?>