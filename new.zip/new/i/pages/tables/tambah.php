<?php include "header.php";?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Siswa Kita
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <CENTER><h3 class="box-title">DATA SISWA SMK CENDEKIA</h3></CENTER>
            </div>
            <!-- /.box-header -->
            <center><p><a href="data.php"><button class="btn btn-primary"><i class="glyphicon glyphicon-home"></i> Beranda</button></a> / <a href="tambah.php"><button class="btn btn-success"><i class="glyphicon glyphicon-plus"></i>Tambah data</button></a></p></center>
            <div class="box-body">
                <form action="tambah_proses.php" method="post"> 
                 <fieldset>
                 <div class="form-group">
                 <label>Nis</label>
                 <input class="form-control" name="nis" type="text" placeholder="nis" required>

                 </div>
                 <label>Nama Lengkap</label>
                 <div class="form-group">
                 <input class="form-control" name="nama" type="text" placeholder="nama" required>
                 </div>
                 <label>Kelas</label>
                  <div class="form-group">
          <select class="form-control" name="kelas" required>
            <option value="">Pilih Kelas</option>
            <option value="X">X</option>
            <option value="XI">XI</option>
            <option value="XII">XII</option>
          </select>
        </td>
      </tr>
      </div>
      <tr>
        <label>Jurusan</label>
        <div class="form-group">

        
          <select class="form-control" name="jurusan" required>
            <option value="">Pilih Jurusan</option>
            <option value="Teknik Komputer dan Jaringan">Teknik Komputer dan Jaringan</option>
            <option value="Multimedia">Multimedia</option>
            <option value="Akuntansi">Akuntansi</option>
            <option value="Perbankan">Perbankan</option>
            <option value="Pemasaran">Pemasaran</option>
            <option value="Rekayasa Perangkat Lunak">Rekayasa Perangkat Lunak</option>
          </select>
        </td>
</div>
        </tr>
        <input type="submit" name="simpan" value="simpan" class="btn btn-success" >
        </fieldset>
        </form>

             
              </table>
 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include "footer.php";?>