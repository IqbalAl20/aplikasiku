<?php include "header.php";?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Data Siswa Kita
        <small></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Tables</a></li>
        <li class="active">Data tables</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <CENTER><h3 class="box-title">DATA SISWA SMK CENDEKIA</h3></CENTER>
            </div>
            <!-- /.box-header -->
            <p><a href="tambah.php"><button class="btn btn-success"><i class="glyphicon glyphicon-plus"></i> Tambah data</button></a></p>
            <div class="box-body">

              <table id="example1" class="table table-bordered table-hover">
                <thead>
                <tr bgcolor="#CCCCCC">
      <th>No.</th>
      <th>NIS</th>
      <th>Nama Lengkap</th>
      <th>Kelas</th>
      <th>Jurusan</th>
    
      <th>Opsi</th>
    </tr>
  </thead>
  <tbody>
    <?php
    //iclude file koneksi ke database
    include('../../../koneksi.php');
    
   $query = mysql_query("SELECT * FROM siswa");
 
$no=1;
      
        while($d=mysql_fetch_array($query)){


  
      
      echo '<tr>';
          echo '<td>'.$no.'</td>';  //menampilkan nomor urut
          echo '<td>'.$d['siswa_nis'].'</td>';  //menampilkan data nis dari database
          echo '<td>'.$d['siswa_nama'].'</td>'; //menampilkan data nama lengkap dari database
          echo '<td>'.$d['siswa_kelas'].'</td>';  //menampilkan data kelas dari database
          echo '<td>'.$d['siswa_jurusan'].'</td>';

        
          //echo '<td >'.'<img src="file/'.$d['nama_upload'].'" height="50">'.'</td>';

          echo '<td><a href="edit.php?id='.$d['siswa_id'].'"><button class="btn btn-warning"><i class="glyphicon glyphicon-pencil"></i></button></a> / <a href="hapus.php?id='.$d['siswa_id'].'" onclick="return confirm(\'Yakin?\')"><button class="btn btn-danger"><i class="glyphicon glyphicon-trash"></i>
          </button></a></td>'; 

        echo '</tr>'; 


    
              
          
  
  $no++;
    
      } 

        
        ?>
        </tbody>
   
              </table>
 </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include "footer.php";?>