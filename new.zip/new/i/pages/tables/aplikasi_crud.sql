-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2018 at 02:30 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aplikasi_crud`
--

-- --------------------------------------------------------

--
-- Table structure for table `siswa`
--

CREATE TABLE `siswa` (
  `siswa_id` int(11) NOT NULL,
  `siswa_nis` int(20) NOT NULL,
  `siswa_nama` varchar(50) NOT NULL,
  `siswa_kelas` varchar(10) NOT NULL,
  `siswa_jurusan` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `siswa`
--

INSERT INTO `siswa` (`siswa_id`, `siswa_nis`, `siswa_nama`, `siswa_kelas`, `siswa_jurusan`) VALUES
(1, 868787, 'ifu', 'XII', 'Multimedia'),
(10, 67867, 'dilla', 'X', 'Teknik Komputer dan Jaringan'),
(11, 67678, 'rahma', 'X', 'Rekayasa Perangkat Lunak'),
(9, 7567676, 'iqbal', 'XI', 'Rekayasa Perangkat Lunak'),
(12, 678678, 'zaenal', 'XII', 'Teknik Komputer dan Jaringan'),
(13, 76788, 'siget', 'XI', 'Rekayasa Perangkat Lunak'),
(14, 8989, 'alfin', 'XI', 'Rekayasa Perangkat Lunak'),
(15, 787878, 'aldi', 'XI', 'Rekayasa Perangkat Lunak'),
(16, 878678, 'amin', 'XI', 'Rekayasa Perangkat Lunak'),
(17, 7867, 'dani', 'XI', 'Rekayasa Perangkat Lunak'),
(18, 87768, 'adi', 'X', 'Rekayasa Perangkat Lunak'),
(19, 756756, 'danang', 'X', 'Rekayasa Perangkat Lunak'),
(20, 767668, 'FGUJGYJH', 'X', 'Multimedia'),
(21, 8787, 'afsgfg', 'X', 'Multimedia'),
(22, 8688, 'hsgh', 'XI', 'Akuntansi'),
(23, 78878, 'fghf', 'X', 'Akuntansi'),
(24, 5676576, 'ajkjhs', 'X', 'Akuntansi'),
(25, 7927, 'dgfj', 'X', 'Pemasaran'),
(26, 37847, 'jhagdjksh', 'X', 'Perbankan'),
(27, 767899, 'jkjkjk', 'X', 'Multimedia'),
(28, 78364876, 'uweuiw', 'XI', 'Multimedia'),
(29, 67576576, 'heri', 'X', 'Multimedia'),
(30, 89898, 'dol', 'XI', 'Rekayasa Perangkat Lunak'),
(31, 5757, 'jkjh', 'XI', 'Rekayasa Perangkat Lunak');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id_upload` int(11) NOT NULL,
  `nama_upload` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id_upload`, `nama_upload`) VALUES
(8, 'Chrysanthemum.jpg'),
(9, 'Koala.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`siswa_id`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id_upload`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `siswa`
--
ALTER TABLE `siswa`
  MODIFY `siswa_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id_upload` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
