<?php include 'header.php';?>
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Version 2.0</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="../localhost/new/i/index.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
                  <div class="col-xs-12">

                  <div class="box">
                    <div class="box-body">
                    <center><h3>SELAMAT DATANG DI APLIKASI PENDATAAN SISWA SMK CENDEKIA LASEM</h3></center><br></br>
                    <center><img src="logo2.png"></center><br></br>
                    </div>
                    </div>
                    </div>
                    </div>


      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php include 'footer.php';?>